// Package winres 生成windows资源
package winres

//go:generate go run github.com/Mrs4s/go-cqhttp/winres/gen
