package encryption

var T544Signer = map[string]func(int64, []byte) []byte{}
