//go:build !amd64

package t544

func init() {

}
